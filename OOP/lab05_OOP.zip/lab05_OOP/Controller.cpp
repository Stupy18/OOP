#include "Controller.h"
#include <iostream>
#include <algorithm>

namespace controller {


// hier ist der Komparison fur sort_by_expiration_date method, wenn a.jahr=b.jahr dann probieren wir a.monat mit b.monat und so fur a.tag und b.tag
    bool sort_by_expiration_date_(const domain::Vehicle &a, const domain::Vehicle &b) {
        if (a.getLaunchDate().year != b.getLaunchDate().year) {
            return a.getLaunchDate().year < b.getLaunchDate().year;
        } else if (a.getLaunchDate().month != b.getLaunchDate().month) {
            return a.getLaunchDate().month < b.getLaunchDate().month;
        }
        return a.getLaunchDate().day < b.getLaunchDate().day;
    }

    vector<domain::Vehicle> Controller::getAllVehiclesSortedByAge() const {
        vector<Vehicle> result = repo_->getAll();
        sort(result.begin(), result.end(), sort_by_expiration_date_);
        return result;
        return {};
    }

    bool Controller::isInList(const std::string &identifier) {
        for (const auto &vehicle: getAllVehicles()) {
            if (vehicle.getIdentifier() == identifier) {
                return true;
            }
        }
        return false;
    }


    vector<Vehicle> Controller::findByStatus(VehicleStatus status) {
        vector<Vehicle> result;
        for (const auto &vehicle: getAllVehicles()) {
            if (vehicle.getStatus() == status) {
                result.push_back(vehicle);
            }
        }
        return result;
    }

    Vehicle Controller::findByID(const std::string &identifier) {
        for (const auto &vehicle: getAllVehicles()) {
            if (vehicle.getIdentifier() == identifier) {
                return vehicle;
            }
        }
        return Vehicle("", "", {0, 0, 0}, 0.0, "", PARKED, "");  // Empty Vehicle object if no matching vehicle is found
    }

    bool Controller::exists(const std::string &identifier) {
        for (const auto &vehicle: getAllVehicles()) {
            if (vehicle.getIdentifier() == identifier) {
                return true;
            }
        }
        return false;
    }

    void Controller::addVehicle(const std::string &identifier, const std::string &model, const date launchDate,
                                double kilometers, const std::string &location, VehicleStatus status, string custoID) {
        if (isInList(identifier))
            throw invalid_argument("Vehicle already in list");
        Vehicle vehicle(identifier, model, launchDate, kilometers, location, status, custoID);
        repo_->create(vehicle);

    }

    void Controller::updateVehicle(const std::string &identifier, const std::string &model, const date launchDate,
                                   double kilometers, const std::string &location, VehicleStatus status,
                                   string custoID) {
        Vehicle vehicle(identifier, model, launchDate, kilometers, location, status, custoID);
        repo_->update(vehicle);
    }

    void Controller::removeVehicle(const std::string &identifier) {
        Vehicle vehicle(identifier, "", {0, 0, 0}, 0.0, "", VehicleStatus::PARKED, "no-one anymore");
        repo_->remove(vehicle.getIdentifier());
    }

    std::vector<Vehicle> Controller::getAllVehicles() const {
        return repo_->getAll();
        return {};
    }

    std::vector<domain::Vehicle> Controller::filterVehiclesByKilometers(double kilometers) const {
        std::vector<domain::Vehicle> filteredVehicles;
        std::vector<domain::Vehicle> vehicles = repo_->getAll();

        for (const auto &vehicle: vehicles) {
            if (vehicle.getKilometers() <= kilometers) {
                filteredVehicles.push_back(vehicle);
            }
        }

        return filteredVehicles;
    }


    std::vector<Vehicle> Controller::getVehiclesByAge(const date launchDate) const {
        std::vector<Vehicle> vehicles = repo_->getAll();
        std::vector<Vehicle> filteredVehicles;

        for (const auto &vehicle: vehicles) {
            if (vehicle.getLaunchDate().year == launchDate.year &&
                vehicle.getLaunchDate().month == launchDate.month &&
                vehicle.getLaunchDate().day == launchDate.day) {
                filteredVehicles.push_back(vehicle);
            }
        }
    }

    std::vector<Vehicle> Controller::getVehiclesByLocation(const std::string &location) const {
        std::vector<Vehicle> vehicles = repo_->getAll();
        std::vector<Vehicle> filteredVehicles;

        for (const auto &vehicle: vehicles) {
            if (vehicle.getLastLocation().find(location) != string::npos) {
                filteredVehicles.push_back(vehicle);
            }
        }

        return filteredVehicles;
    }

    void Controller::reserveVehicle(const std::string &identifier, const string currentCustomerID) {
        std::vector<Vehicle> vehicles = repo_->getAll();

        for (auto &vehicle: vehicles) {
            if ((vehicle.getIdentifier() == identifier)) {
                if ((vehicle.getStatus() != domain::RESERVED && vehicle.getStatus() != domain::IN_USE &&
                     getCurrentCustomerID().empty())) {
                    vehicle.setStatus(VehicleStatus::RESERVED);
                    vehicle.setCustomerID(currentCustomerID);
                    repo_->update(vehicle);
                    break;
                } else {
                    cout << "Not yours boss" << endl;
                    break;
                }
            }
        }
    }

    void Controller::useVehicle(const std::string &identifier, const string currentCustomerID) {
        std::vector<Vehicle> vehicles = repo_->getAll();

        for (auto &vehicle: vehicles) {
            if (vehicle.getIdentifier() == identifier && vehicle.getCustomerID() == currentCustomerID &&
                vehicle.getStatus() == domain::RESERVED) {
                vehicle.setStatus(VehicleStatus::IN_USE);
                repo_->update(vehicle);
                cout << "Vehicle marked as in use!" << endl;
                break;
            } else {
                cout << "You didn't reserve this boss" << endl;
                break;
            }
        }
    }

    void Controller::setCurrentCustomerID(const std::string &customerID) {
        currentCustomerID_ = customerID;
    }

    std::string Controller::getCurrentCustomerID() const {
        return currentCustomerID_;
    }


    std::vector<Vehicle> Controller::getReservedVehiclesForCustomer(const std::string &customerID) const {
        std::vector<Vehicle> vehicles = repo_->getAll();
        std::vector<Vehicle> reservedVehicles;

        for (const auto &vehicle: vehicles) {
            if (vehicle.getCustomerID() == customerID && vehicle.getStatus() == VehicleStatus::RESERVED) {
                reservedVehicles.push_back(vehicle);
            }
        }

        return reservedVehicles;
    }


}
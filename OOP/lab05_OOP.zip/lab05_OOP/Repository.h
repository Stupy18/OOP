#ifndef REPOSITORY_H
#define REPOSITORY_H

#include <vector>
#include <fstream>
#include <sstream>
#include "Domain.h"

using namespace std;

template <typename T>
class CrudRepository {
public:
    virtual void create(const T& obj) = 0;
    virtual vector<T> getAll() const = 0;
    virtual void update(T& obj) = 0;
    virtual void remove(const string& identifier) = 0;
    virtual ~CrudRepository() {}
};

namespace repo {
    using namespace domain; // Move the 'using namespace domain;' statement here

    class InMemoryRepository : public CrudRepository<Vehicle> {
    private:
        vector<Vehicle> vehicles;

    public:
        InMemoryRepository();

        void create(const Vehicle& obj) override;
        vector<Vehicle> getAll() const override;
        void update(Vehicle& obj) override;
        void remove(const string& identifier) override;
    };

    class CSVFileRepository : public CrudRepository<Vehicle> {
    private:
        string filename;
        vector<Vehicle> vehicles;

        void loadVehiclesFromCSV();
        void saveVehiclesToCSV();
        string getStatusString(VehicleStatus status) const;

    public:
        CSVFileRepository(const string& csvFilename);

        void create(const Vehicle& obj) override;
        vector<Vehicle> getAll() const override;
        void update(Vehicle& obj) override;
        void remove(const string& identifier) override;
    };
}
#endif // REPOSITORY_H
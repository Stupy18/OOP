//
// Created by stupa on 5/10/2023.
//
using namespace std;

#include "Domain.h"
#include <iostream>
#include <algorithm>

using namespace domain;
namespace domain {




    Vehicle::Vehicle(string identifier, string model, date launchDate, double kilometers, string lastLocation,
                     VehicleStatus status,string customerID) {
        this->identifier_ = identifier;
        this->model_ = model;
        this->launchDate_ = launchDate;
        this->kilometers_ = kilometers;
        this->lastLocation_ = lastLocation;
        this->status_ = status;
        this->customerID_ = customerID;
    }

    string Vehicle::getStatusString(VehicleStatus status) {
        switch (status) {
            case VehicleStatus::PARKED:
                return "PARKED";
            case VehicleStatus::RESERVED:
                return "RESERVED";
            case VehicleStatus::IN_USE:
                return "IN USE";
            case VehicleStatus::MAINTENANCE:
                return "MAINTENANCE";
            case VehicleStatus::OUT_OF_ORDER:
                return "OUT OF ORDER";
            default:
                return "UNKNOWN";
        }
    }

    string Vehicle::getIdentifier() const {
        return identifier_;
    }

    void Vehicle::setIdentifier(const string &identifier) {
        this->identifier_ = identifier;
    }


    string Vehicle::getModel() const {
        return model_;
    }

    void Vehicle::setModel(const string &model) {
        this->model_ = model;
    }


    date Vehicle::getLaunchDate() const {
        return launchDate_;
    }

    void Vehicle::setLaunchDate(const date &launchDate) {
        this->launchDate_ = launchDate;
    }


    double Vehicle::getKilometers() const {
        return kilometers_;
    }

    void Vehicle::setKilometers(double kilometers) {
        this->kilometers_ = kilometers;
    }


    string Vehicle::getLastLocation() const {
        return lastLocation_;
    }

    void Vehicle::setLastLocation(const string &lastLocation) {
        this->lastLocation_ = lastLocation;
    }


    VehicleStatus Vehicle::getStatus() const {
        return status_;
    }

    void Vehicle::setStatus(VehicleStatus status) {
        this->status_ = status;
    }
    void printVehicleVector(vector<domain::Vehicle> vec){
        for(auto vehicle_ : vec){
            std::cout<<"\n {id:"<<vehicle_.getIdentifier()<<"  model:"<<vehicle_.getModel()<<"  launch date:"<<vehicle_.getLaunchDate().day<<"/"<<vehicle_.getLaunchDate().month<<"/"<<vehicle_.getLaunchDate().year<<"  kilometers:"<<vehicle_.getKilometers()<<"  location:"<<vehicle_.getLastLocation()<<"  status:"<<vehicle_.getStatusString(vehicle_.getStatus())<<"   customer ID:"<<vehicle_.getCustomerID()<<"}\n";
        }
    }
}
#ifndef TEST_H
#define TEST_H

void testControllerMethods();
void nonUITests();
void uiTest();

#include <iostream>
#include <cassert>
#include "Controller.h"
#include "Domain.h"
#include "Repository.h"
#include "UI.h"
#include "test.h"

using namespace std;
using namespace domain;
using namespace repo;
using namespace controller;
using namespace ui;

void testControllerMethods() {
    // Create a shared_ptr to InMemoryRepository
    std::shared_ptr<repo::InMemoryRepository> inMemoryRepo = std::make_shared<repo::InMemoryRepository>();
    controller::Controller controller(inMemoryRepo);

    // Test getAllVehiclesSortedByAge method
    std::vector<domain::Vehicle> sortedVehicles = controller.getAllVehiclesSortedByAge();
    assert(sortedVehicles.size() == 10);
    assert(sortedVehicles[0].getIdentifier() == "IRS");
    assert(sortedVehicles[1].getIdentifier() == "PZD");
    assert(sortedVehicles[2].getIdentifier() == "MUE");

    // Test findByStatus method
    std::vector<domain::Vehicle> reservedVehicles = controller.findByStatus(domain::VehicleStatus::RESERVED);
    assert(reservedVehicles.size() == 2);
    assert(reservedVehicles[0].getIdentifier() == "ABC");

    // Test findByID method
    domain::Vehicle vehicle = controller.findByID("DEF");
    assert(vehicle.getIdentifier() == "DEF");
    assert(vehicle.getModel() == "Model Y");

    // Test exists method
    bool exists = controller.exists("GHE");
    assert(exists);

    exists = controller.exists("LOL");
    assert(!exists);

    // Test updateVehicle method
    controller.updateVehicle("DEF", "Updated Model", {2023, 5, 24}, 2500.0, "Updated Location", domain::VehicleStatus::MAINTENANCE, "");
    vehicle = controller.findByID("DEF");
    assert(vehicle.getIdentifier() == "DEF");
    assert(vehicle.getModel() == "Updated Model");
    assert(vehicle.getLaunchDate().year == 2023);
    assert(vehicle.getKilometers() == 2500.0);
    assert(vehicle.getLastLocation() == "Updated Location");
    assert(vehicle.getStatus() == domain::VehicleStatus::MAINTENANCE);

    // Test removeVehicle method
    controller.removeVehicle("ABC");
    exists = controller.exists("ABC");
    assert(!exists);

    // Test getAllVehicles method
    std::vector<domain::Vehicle> allVehicles = controller.getAllVehicles();
    assert(allVehicles.size() == 9);

}

void nonUITests() {
    repo::CSVFileRepository csvRepo("C:\\Users\\stupa\\CLionProjects\\lab05_OOP\\CSVRepo.txt");
    repo::InMemoryRepository inMemoRepo;
    csvRepo.create(Vehicle("REPOTEST", "2", date{1, 2, 3}, 15, "c", VehicleStatus::OUT_OF_ORDER, ""));
    csvRepo.create(Vehicle("REPOTEST2", "23", date{1, 2, 3}, 15, "c", VehicleStatus::OUT_OF_ORDER, ""));
    auto scoots = csvRepo.getAll();
    printVehicleVector(scoots);

    controller::Controller csvCtrl(make_shared<CSVFileRepository>(csvRepo));
    controller::Controller inMemoCtrl(make_shared<InMemoryRepository>(inMemoRepo));

}

void uiTest() {
    ui::UI ui;
    ui.printMenu();
}

#endif
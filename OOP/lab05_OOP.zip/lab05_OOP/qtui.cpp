#include "qtui.h"
#include <QVBoxLayout>
#include <QTableWidgetItem>
#include <QFileDialog>
#include <QMessageBox>
#include "Domain.h"

const int NUM_COLUMNS = 7;

QTUI::QTUI(QWidget *parent)
        : QWidget(parent)
{
    tableWidget = new QTableWidget(this);
    tableWidget->setSortingEnabled(true);
    // Adjust the number of columns based on the number of attributes you want to display

    setLayout(new QVBoxLayout);
    layout()->addWidget(tableWidget);
}

QTUI::~QTUI()
{
    delete tableWidget;
}

void QTUI::displayVehicles(const std::vector<domain::Vehicle>& vehicles)
{
    tableWidget->clear();

    // Set the number of rows and columns based on the size of the vehicles vector
    tableWidget->setRowCount(vehicles.size());
    tableWidget->setColumnCount(NUM_COLUMNS); // Adjust the number of columns

    // Set the headers for each column
    tableWidget->setHorizontalHeaderItem(0, new QTableWidgetItem("Identifier"));
    tableWidget->setHorizontalHeaderItem(1, new QTableWidgetItem("Model"));
    tableWidget->setHorizontalHeaderItem(2, new QTableWidgetItem("Launch Date"));
    tableWidget->setHorizontalHeaderItem(3, new QTableWidgetItem("Kilometers"));
    tableWidget->setHorizontalHeaderItem(4, new QTableWidgetItem("Last Location"));
    tableWidget->setHorizontalHeaderItem(5, new QTableWidgetItem("Status"));
    tableWidget->setHorizontalHeaderItem(6, new QTableWidgetItem("Customer ID"));

    // Populate the table with vehicle data
    for (int row = 0; row < vehicles.size(); ++row)
    {
        const domain::Vehicle& vehicle = vehicles[row];

        QTableWidgetItem* identifierItem = new QTableWidgetItem(vehicle.getIdentifier().c_str());
        QTableWidgetItem* modelItem = new QTableWidgetItem(vehicle.getModel().c_str());
        QTableWidgetItem* launchDateItem = new QTableWidgetItem(QString::number(vehicle.getLaunchDate().day) + "/" +
                                                                QString::number(vehicle.getLaunchDate().month) + "/" +
                                                                QString::number(vehicle.getLaunchDate().year));
        QTableWidgetItem* kilometersItem = new QTableWidgetItem(QString::number(vehicle.getKilometers()));
        QTableWidgetItem* lastLocationItem = new QTableWidgetItem(vehicle.getLastLocation().c_str());
        QTableWidgetItem* statusItem = new QTableWidgetItem((vehicle.getStatus()));
        QTableWidgetItem* customerIDItem = new QTableWidgetItem(vehicle.getCustomerID().c_str());

        // Set the items in the table
        tableWidget->setItem(row, 0, identifierItem);
        tableWidget->setItem(row, 1, modelItem);
        tableWidget->setItem(row, 2, launchDateItem);
        tableWidget->setItem(row, 3, kilometersItem);
        tableWidget->setItem(row, 4, lastLocationItem);
        tableWidget->setItem(row, 5, statusItem);
        tableWidget->setItem(row, 6, customerIDItem);
    }

    // Resize the columns to fit the content
    tableWidget->resizeColumnsToContents();
}

void QTUI::openCSV()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open CSV File", "", "CSV Files (*.csv)");

    if (!fileName.isEmpty())
    {
        // Read the CSV file and populate the vehicle list
        std::vector<domain::Vehicle> vehicles = readCSV(fileName.toStdString());

        if (!vehicles.empty())
        {
            displayVehicles(vehicles);
        }
        else
        {
            QMessageBox::critical(this, "Error", "Failed to load vehicles from the CSV file.");
        }
    }
}

std::vector<domain::Vehicle> QTUI::readCSV(const std::string& fileName)
{
    // Code to read the CSV file and populate the vehicle list
    // Implement this function according to your specific CSV format

    // Placeholder implementation
    std::vector<domain::Vehicle> vehicles;
    vehicles.push_back(domain::Vehicle("ID1", "Model1", {1, 1, 2023}, 1000, "Location1", "Status1", "Customer1"));
    vehicles.push_back(domain::Vehicle("ID2", "Model2", {2, 2, 2023}, 2000, "Location2", "Status2", "Customer2"));
    vehicles.push_back(domain::Vehicle("ID3", "Model3", {3, 3, 2023}, 3000, "Location3", "Status3", "Customer3"));

    return vehicles;
}

void QTUI::showVehicleDetails(const QModelIndex& index)
{
    if (index.isValid())
    {
        int row = index.row();
        const QTableWidgetItem* identifierItem = tableWidget->item(row, 0);

        if (identifierItem)
        {
            QString identifier = identifierItem->text();

            // Retrieve the corresponding vehicle based on the selected identifier
            // and display the details in a separate dialog or widget

            // Placeholder implementation
            QMessageBox::information(this, "Vehicle Details", "Display details for vehicle with ID: " + identifier);
        }
    }
}
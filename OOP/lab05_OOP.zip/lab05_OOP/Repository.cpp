#include "Repository.h"

namespace repo {
    InMemoryRepository::InMemoryRepository() {
        // Programmatically add 10 cars at program start
        vehicles.push_back(Vehicle("ABC", "Model X", {2020, 1, 1}, 1000.0, "Braila", RESERVED,""));
        vehicles.push_back(Vehicle("DEF", "Model Y", {2021, 2, 2}, 2000.0, "Jilava", PARKED,""));
        vehicles.push_back(Vehicle("GHE", "Model Z", {2022, 3, 3}, 3000.0, "Craiova", IN_USE,""));
        vehicles.push_back(Vehicle("JKL", "Model A", {2019, 4, 4}, 4000.0, "Septimiu", MAINTENANCE,""));
        vehicles.push_back(Vehicle("MNO", "Model B", {2018, 5, 5}, 5000.0, "Sighisoara", OUT_OF_ORDER,""));
        vehicles.push_back(Vehicle("PQR", "Model C", {2017, 6, 6}, 6000.0, "Parc", RESERVED,""));
        vehicles.push_back(Vehicle("STU", "Model D", {2016, 7, 7}, 7000.0, "OOP", PARKED,""));
        vehicles.push_back(Vehicle("MUE", "Model E", {2015, 8, 8}, 8000.0, "David", IN_USE,""));
        vehicles.push_back(Vehicle("PZD", "Model F", {2014, 9, 9}, 9000.0, "Mihai", MAINTENANCE,""));
        vehicles.push_back(Vehicle("IRS", "Model G", {2013, 10, 10}, 10000.0, "Stupy", OUT_OF_ORDER,""));
    }


    void InMemoryRepository::create(const Vehicle& obj) {
        vehicles.push_back(obj);
    }

    vector<Vehicle> InMemoryRepository::getAll() const {
        return vehicles;
    }

    void InMemoryRepository::update(Vehicle& obj) {
        for (auto& vehicle : vehicles) {
            if (vehicle.getIdentifier() == obj.getIdentifier()) {
                vehicle = obj;
                break;
            }
        }
    }

    void InMemoryRepository::remove(const string& identifier) {
        for (auto it = vehicles.begin(); it != vehicles.end(); ++it) {
            if (it->getIdentifier() == identifier) {
                vehicles.erase(it);
                break;
            }
        }
    }

    CSVFileRepository::CSVFileRepository(const string& filename) : filename(filename) {
        loadVehiclesFromCSV();
    }

    void CSVFileRepository::loadVehiclesFromCSV() {
        ifstream file(filename);
        if(!file.is_open()){
            //throw runtime_error("File failed to open");
            std::ofstream fileAux(filename, std::ios::out | std::ios::app);
            file.close();
            std::ifstream file(filename, std::ios::in);
        }
        else{
            string line;
            while (getline(file, line)) {
                stringstream ss(line);
                string identifier, model, launchDateStr, kilometersStr, location, statusStr,custoID;
                getline(ss, identifier, ',');
                getline(ss, model, ',');
                getline(ss, launchDateStr, ',');
                getline(ss, kilometersStr, ',');
                getline(ss, location, ',');
                getline(ss, statusStr, ',');
                getline(ss,custoID,',');

                date launchDate;
                sscanf(launchDateStr.c_str(), "%d-%d-%d", &launchDate.year, &launchDate.month, &launchDate.day);
                double kilometers = stod(kilometersStr);
                VehicleStatus status;
                if (statusStr == "parked") {
                    status = VehicleStatus::PARKED;
                } else if (statusStr == "reserved") {
                    status = VehicleStatus::RESERVED;
                } else if (statusStr == "in_use") {
                    status = VehicleStatus::IN_USE;
                } else if (statusStr == "maintenance") {
                    status = VehicleStatus::MAINTENANCE;
                } else if (statusStr == "out_of_order") {
                    status = VehicleStatus::OUT_OF_ORDER;
                } else {
                    status = VehicleStatus::PARKED; // Default status
                }

                vehicles.push_back(Vehicle(identifier, model, launchDate, kilometers, location, status,custoID));
            }
            file.close();
        }
    }

    void CSVFileRepository::saveVehiclesToCSV() {
        std::ofstream file(filename, std::ios::out | std::ios::trunc);
        if(!file.is_open())
            throw runtime_error("File failed to open");
        else{
            for (const auto& vehicle : vehicles) {
                file << vehicle.getIdentifier() << ","
                     << vehicle.getModel() << ","
                     << vehicle.getLaunchDate().year << "-" << vehicle.getLaunchDate().month << "-" << vehicle.getLaunchDate().day << ","
                     << vehicle.getKilometers() << ","
                     << vehicle.getLastLocation() << ","
                     << getStatusString(vehicle.getStatus()) << ","
                     << vehicle.getCustomerID() << endl;
            }
            file.close();
        }
    }


    string CSVFileRepository::getStatusString(VehicleStatus status) const {
        switch (status) {
            case VehicleStatus::PARKED: return "parked";
            case VehicleStatus::RESERVED: return "reserved";
            case VehicleStatus::IN_USE: return "in_use";
            case VehicleStatus::MAINTENANCE: return "maintenance";
            case VehicleStatus::OUT_OF_ORDER: return "out_of_order";
            default: return "";
        }
    }

    void CSVFileRepository::create(const Vehicle& obj) {
        vehicles.push_back(obj);
        saveVehiclesToCSV();
    }

    vector<Vehicle> CSVFileRepository::getAll() const {
        return vehicles;
    }

    void CSVFileRepository::update(Vehicle& obj) {
        for (auto& vehicle : vehicles) {
            if (vehicle.getIdentifier() == obj.getIdentifier()) {
                vehicle = obj;
                break;
            }
        }
        saveVehiclesToCSV();
    }

    void CSVFileRepository::remove(const string& identifier) {
        for (auto it = vehicles.begin(); it != vehicles.end(); ++it) {
            if (it->getIdentifier() == identifier) {
                vehicles.erase(it);
                break;
            }
        }
        saveVehiclesToCSV();
    }
}
#pragma once

#include "Controller.h"
#include <iostream>

using namespace controller;

namespace ui {




    class UI {
    private:
        std::shared_ptr<controller::Controller> ctrl_;

    public:
        UI();
        void handleManagerRole();
        void handleCustomerRole();
        void printMenu();
        string stringUpperCase(const std::string &str) {
            std::string result;
            result.reserve(str.length());

            for (char c: str) {
                result += std::toupper(c); ///we turn the entire string into uppercase
            }
            return result;
        }

    };

}


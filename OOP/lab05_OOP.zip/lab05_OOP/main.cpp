#include <iostream>
#include <memory>
#include <cassert>
#include "Controller.h"
#include "Domain.h"
#include "Repository.h"
#include "UI.h"
#include <assert.h>
#include "test.h"
#include "qtui.h"
#include <QApplication>


using namespace std;
using namespace domain;
using namespace repo;
using namespace controller;
using namespace ui;

int main(int argc, char *argv[]) {
    testControllerMethods();
    nonUITests();
    uiTest();

    QApplication app(argc, argv);

    // Create an instance of the Repository class
    repo::CSVFileRepository repository("Lab5.txt");

    // Create an instance of the Controller class with the repository
    controller::Controller controller(make_shared<repo::CSVFileRepository>(repository));

    // Create an instance of the QTUI class
    QTUI qtui;

    // Retrieve the vehicles from the controller
    std::vector<domain::Vehicle> vehicles = controller.getAllVehicles();

    // Display the vehicles in the QTUI
    qtui.displayVehicles(vehicles);

    // Show the QTUI window
    qtui.show();

    // Run the application event loop
    return app.exec();
}

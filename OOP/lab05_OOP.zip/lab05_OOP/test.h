#ifndef TEST_H
#define TEST_H

void testControllerMethods();
void nonUITests();
void uiTest();

#endif
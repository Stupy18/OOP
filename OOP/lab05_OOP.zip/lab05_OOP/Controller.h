// Controller.h
#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <vector>
#include <memory>
#include "Repository.h"
#include "Domain.h"

using namespace repo;
using namespace domain;
namespace controller {

    class Controller {

    private:

        string currentCustomerID_;
        shared_ptr<CrudRepository<Vehicle>> repo_;

    public:

        Controller(std::shared_ptr<CrudRepository<Vehicle>> repo)
                : repo_(std::move(repo)) {}

        bool isInList(const std::string &identifier);


        std::vector<domain::Vehicle> filterVehiclesByKilometers(double kilometers) const;

        void addVehicle(const std::string &identifier, const std::string &model, const date launchDate, double kilometers,
                   const std::string &location, VehicleStatus status,string custoID);

        void updateVehicle(const std::string &identifier, const std::string &model, const date launchDate, double kilometers,
                      const std::string &location, VehicleStatus status,string custoID);

        void removeVehicle(const std::string &identifier);

        vector<domain::Vehicle> getAllVehiclesSortedByAge() const;

        vector<Vehicle> getAllVehicles() const;

        vector<Vehicle> getVehiclesByStatus(VehicleStatus status) const;

        vector<Vehicle> getVehiclesByAge(const date launchDate) const;

        vector<Vehicle> getVehiclesByLocation(const std::string &location) const;

        void reserveVehicle(const std::string &identifier, const string currentCustomerID);

        void useVehicle(const std::string &identifier,const string currentCustomerID);

        vector<Vehicle> findByStatus(VehicleStatus status);

        Vehicle findByID(const std::string &identifier);

        bool exists(const string &identifier);

        void setCurrentCustomerID(const string &customerID);

        string getCurrentCustomerID() const;

        vector<Vehicle> getReservedVehiclesForCustomer(const std::string &customerID) const;

    };
}
#endif
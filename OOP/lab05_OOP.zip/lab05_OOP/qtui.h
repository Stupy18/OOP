#pragma once

#include <QWidget>
#include <QTableWidget>
#include <vector>
#include "Domain.h"

class QTUI : public QWidget
{
Q_OBJECT

public:
    explicit QTUI(QWidget *parent = nullptr);
    virtual ~QTUI();

    void displayVehicles(const std::vector<domain::Vehicle>& vehicles);
    std::vector<domain::Vehicle> readCSV(const std::string& fileName);
    void showVehicleDetails(const QModelIndex& index);
    void openCSV();

private:
    QTableWidget* tableWidget;
};
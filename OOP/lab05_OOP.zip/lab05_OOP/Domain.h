#ifndef LAB05_OOP_DOMAIN_H
#define LAB05_OOP_DOMAIN_H

#include <string>
#include <vector>
using namespace std;

namespace domain {

    struct date {
        int year = 0;
        int month = 0;
        int day = 0;
    };

    enum VehicleStatus {
        PARKED,
        RESERVED,
        IN_USE,
        MAINTENANCE,
        OUT_OF_ORDER
    };

    class Vehicle {

    private:

        string identifier_="";
        string model_="";
        date launchDate_={0,0,0};
        double kilometers_=0.0;
        string lastLocation_="";
        VehicleStatus status_=PARKED;
        string customerID_;

    public:

        string getStatusString(VehicleStatus status) ;

        Vehicle(string identifier, string model, date launchDate, double kilometers, string lastLocation, VehicleStatus status,string customerID);

        string getCustomerID() const {
            return customerID_;
        }

        void setCustomerID(const string& id) {
            this->customerID_ = id;
        }

        string getIdentifier() const;
        void setIdentifier(const string &identifier);

        string getModel() const;
        void setModel(const string &model);

        date getLaunchDate() const;
        void setLaunchDate(const date &launchDate);

        double getKilometers() const;
        void setKilometers(double kilometers);

        string getLastLocation() const;
        void setLastLocation(const string &lastLocation);


        VehicleStatus getStatus() const;
        void setStatus(VehicleStatus status);

    };
    void printVehicleVector(vector<Vehicle> vec);

}
#endif //LAB05_OOP_DOMAIN_H


#ifndef LAB2_OOP_L2_STUPARIU_BOGDAN_PROBLEM1_DURATION_H
#define LAB2_OOP_L2_STUPARIU_BOGDAN_PROBLEM1_DURATION_H

#include <string>
using namespace std;

class Duration {
private:
    double value;
    std::string unit;
public:
    // Constructor
    Duration(double value, const std::string& unit);

    // Accessors
    double get_value() const;
    const string& get_unit() const;

    // Operations
    Duration add(const Duration& other) const;
    Duration subtract(const Duration& other) const;
    Duration scale(double factor) const;
    Duration divide(double divisor) const;
    std::string text() const;
    int compare(const Duration& other) const;

    //Operators
    Duration operator+(const Duration& other) const;
    Duration operator-(const Duration& other) const;
    Duration operator*(double factor) const;
    Duration operator/(double factor) const;

};

#endif

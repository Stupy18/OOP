#include "L2_Stupariu_Bogdan_Problem1_duration.h"
#include <sstream>
#include <iomanip>

using namespace std;


// Constructor
Duration::Duration(double value, const std::string &unit) :
        value(value), unit(unit) {
}

// Accessors
double Duration::get_value() const {
    return value;
}

const string &Duration::get_unit() const {
    return unit;
}

Duration Duration::add(const Duration &other) const {
    if (unit != other.unit) {
        throw runtime_error("Cannot add different units");
    }
    return Duration(value + other.value, unit);
}

Duration Duration::subtract(const Duration &other) const {
    if (unit != other.unit) {
        throw runtime_error("Cannot add different units");
    }
    return Duration(value - other.value, unit);
}

Duration Duration::scale(double factor) const {
    return Duration(value * factor, unit);
}

Duration Duration::divide(double divisor) const {
    return Duration(value / divisor, unit);
}

string Duration::text() const {
    stringstream ss;
    ss << std::fixed << std::setprecision(2) << value << " " << unit;
    return ss.str();
}
//1-std::stringstream ss; - creates a stringstream object called ss to hold the string representation of
// the duration value and unit.
//
//2-ss << std::fixed << std::setprecision(2) - sets the stream's floating-point output format to fixed
// (to display a fixed number of decimal places) and specifies that it should output 2 decimal places.
//
//3-ss << value - appends the duration value to the stream.
//
//4-ss << " " << unit - appends a space and the duration unit to the stream.
//
//5-return ss.str(); - returns the entire stream as a string.

int Duration::compare(const Duration &other) const {
    if (unit != other.unit) {
        throw runtime_error("Cannot compare different units");
    }
    if (value < other.value) {
        return -1;
    } else if (value > other.value) {
        return 1;
    } else {
        return 0;
    }
}
Duration Duration::operator+(const Duration& other) const {
    return this->add(other);
}

Duration Duration::operator-(const Duration& other) const {
    return this->subtract(other);
}

Duration Duration::operator*(double factor) const {
    return this->scale(factor);
}

Duration Duration::operator/(double factor) const {
    return this->divide(factor);
}



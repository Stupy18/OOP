#include "L2_Stupariu_Bogdan_Problem1_duration.h"

using namespace std;

#include "iostream"
#include <iomanip>
#include <iostream>
#include <cassert>

void test_getters() {
    Duration d1(5, "min");
    assert(d1.get_value() == 5);
    assert(d1.get_unit() == "min");

    Duration d2(10.5, "h");
    assert(d2.get_value() == 10.5);
    assert(d2.get_unit() == "h");
}

void test_add() {
    Duration d1(5, "min");
    Duration d2(3, "min");
    Duration d3 = d1.add(d2);
    assert(d3.get_value() == 8);
    assert(d3.get_unit() == "min");

    Duration d4(1.5, "h");
    Duration d5(2, "h");
    Duration d6 = d4.add(d5);
    assert(d6.get_value() == 3.5);
    assert(d6.get_unit() == "h");

}

void test_subtract() {
    Duration d1(5, "min");
    Duration d2(3, "min");
    Duration d3 = d1.subtract(d2);
    assert(d3.get_value() == 2);
    assert(d3.get_unit() == "min");

    Duration d4(2, "h");
    Duration d5(1.5, "h");
    Duration d6 = d4.subtract(d5);
    assert(d6.get_value() == 0.5);
    assert(d6.get_unit() == "h");


}

void test_scale() {
    Duration d1(5, "min");
    Duration d2 = d1.scale(2);
    assert(d2.get_value() == 10);
    assert(d2.get_unit() == "min");

    Duration d3(1.5, "h");
    Duration d4 = d3.scale(0.5);
    assert(d4.get_value() == 0.75);
    assert(d4.get_unit() == "h");
}

void test_divide() {
    Duration d1(10, "min");
    Duration d2 = d1.divide(2);
    assert(d2.get_value() == 5);
    assert(d2.get_unit() == "min");

    Duration d3(3, "h");
    Duration d4 = d3.divide(1.5);
    assert(d4.get_value() == 2);
    assert(d4.get_unit() == "h");
}

void test_to_string() {
    Duration d1(5, "min");
    assert(d1.text() == "5.00 min");

    Duration d2(10.5, "h");
    assert(d2.text() == "10.50 h");
}

void test_compare() {
    Duration d1(5, "min");
    Duration d2(3, "min");
    assert(d1.compare(d2) == 1);

    Duration d3(1.5, "min");
    Duration d4(90, "min");
    assert(d3.compare(d4) == -1);
}

int main() {
    test_getters();
    test_add();
    test_subtract();
    test_scale();
    test_divide();
    test_to_string();
    test_compare();
    double value1, value2, number;
    string unit1, unit2;

    cout << "Enter first duration value and unit: ";
    cin >> value1 >> unit1;

    cout << "Enter second duration value and unit: ";
    cin >> value2 >> unit2;

    cout << "Enter a number to scale the durations: ";
    cin >> number;

    Duration duration1(value1, unit1);
    Duration duration2(value2, unit2);
    cout << endl;

    cout << "Addition: " << duration1.add(duration2).text() << endl;

    cout << "Subtraction: " << duration1.subtract(duration2).text() << endl;

    cout << "Scaling: " << duration1.scale(number).text() << ", " << duration2.scale(number).text() << endl;

    cout << "Division: " << duration1.divide(number).text() << ", " << duration2.divide(number).text() << endl;

    int comparison = duration1.compare(duration2);
    if (comparison == -1) {
        cout << duration1.text()<< " is less than" << duration2.text() << endl;
    } else if (comparison == 0) {
        cout << duration1.text()<<" is equal to "<< duration2.text()<< endl;
    } else {
        cout << duration1.text()<<" is greater than "<< duration2.text() << endl;
    }

    return 0;
}
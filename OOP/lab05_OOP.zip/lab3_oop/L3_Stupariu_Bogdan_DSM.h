#ifndef LAB3_OOP_L3_STUPARIU_BOGDAN_DSM_H
#define LAB3_OOP_L3_STUPARIU_BOGDAN_DSM_H
using namespace std;
#include <string>

template<typename Weight>
class DSM {
private:

    string *elementNames = nullptr;
    int elementCount = 0;
    Weight **adjacencyMatrix = nullptr;

public:
    DSM(int elementCount);
    DSM(string *elementNames, int elementCount);
    DSM(const DSM& other);
    ~DSM();

    int size() const;

    string getName(int index) const;

    void setElementName(int index, const string &elementName);

    void addLink(const string &fromElement, const string &toElement, const Weight weight);

    void deleteLink(const string &fromElement, const string &toElement);

    bool hasLink(const string &fromElement, const string &toElement) const;

    Weight linkWeight(const string &fromElement, const string &toElement) const;

    int countToLinks(const string &elementName) const;

    int countFromLinks(const string &elementName) const;

    int countAllLinks() const;

    int index(const string &elementName) const ;

    void resize();

    void print() const;

};



#endif //LAB3_OOP_L3_STUPARIU_BOGDAN_DSM_H

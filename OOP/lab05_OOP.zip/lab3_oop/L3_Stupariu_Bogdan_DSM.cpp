#include "L3_Stupariu_Bogdan_DSM.h"
#include <stdexcept>
#include "iostream"

template<typename Weight>
DSM<Weight>::DSM(int elementCount) {
    this->elementCount = elementCount;
    this->elementNames = new string[elementCount];
    this->adjacencyMatrix = new Weight*[elementCount];
    for (int i = 0; i < elementCount; i++) {
        adjacencyMatrix[i] = new Weight[elementCount];
        for (int j = 0; j < elementCount; j++) {
            adjacencyMatrix[i][j] = 0;
        }
    }
}

template<typename Weight>
DSM<Weight>::DSM(string *elementNames, int elementCount) {
    this->elementCount = elementCount;
    this->elementNames = new string[elementCount];
    for (int i = 0; i < elementCount; i++) {
        this->elementNames[i] = elementNames[i];
    }
    this->adjacencyMatrix = new Weight*[elementCount];
    for (int i = 0; i < elementCount; i++) {
        adjacencyMatrix[i] = new Weight[elementCount];
        for (int j = 0; j < elementCount; j++) {
            adjacencyMatrix[i][j] = 0;
        }
    }
}

template<typename Weight>
DSM<Weight>::DSM(const DSM& other) {
//     Deallocate existing memory
    for (int i = 0; i < elementCount; i++) {
        delete[] adjacencyMatrix[i];
    }
    delete[] adjacencyMatrix;
    delete[] elementNames;
//    this->~DSM(); //equal with this ^???

    // Kopieren ElementCount und Name
    this->elementCount = other.elementCount;
    this->elementNames = new string[elementCount];
    for (int i = 0; i < elementCount; i++) {
        this->elementNames[i] = other.elementNames[i];
    }

    // Kopieren von Elemente
    adjacencyMatrix = new int *[elementCount];
    for (int i = 0; i < elementCount; i++) {
        adjacencyMatrix[i] = new int[elementCount];
        for (int j = 0; j < elementCount; j++) {
            adjacencyMatrix[i][j] = other.adjacencyMatrix[i][j];
        }
    }
}

template<typename Weight>
DSM<Weight>::~DSM() {
    delete[] elementNames;
    for (int i = 0; i < elementCount; i++) {
        delete[] adjacencyMatrix[i];
    }
    delete[] adjacencyMatrix;
}

template<typename Weight>
int DSM<Weight>::size() const {
    return elementCount;
}

template<typename Weight>
string DSM<Weight>::getName(int index) const {
    if (index < 0 || index >= elementCount) {
        throw out_of_range("Index out of range");
    }
    return elementNames[index];
}

template<typename Weight>
void DSM<Weight>::setElementName(int index, const string &elementName) {
    if (index < 0 || index >= elementCount) {
        throw out_of_range("Index out of range");
    }
    elementNames[index] = elementName;
}

template<typename Weight>
void DSM<Weight>::addLink(const string &fromElement, const string &toElement, const Weight weight) {
    if(weight < 0 || weight > 10){
        throw invalid_argument("Invalid weight");
    }
    if(fromElement == toElement){
        throw invalid_argument("The string should be different");
    }
    int fromIndex = index(fromElement);
    int toIndex = index(toElement);
    if(fromIndex == -1 || toIndex == -1){
        if(fromIndex == -1){
            resize();
            fromIndex = elementCount - 1;
            elementNames[fromIndex] = fromElement;
        }
        if(toIndex == -1){
            resize();
            toIndex = elementCount - 1;
            elementNames[toIndex] = toElement;
        }
    }

    adjacencyMatrix[fromIndex][toIndex] = weight;
}

template<typename Weight>
void DSM<Weight>::resize() {
    elementCount++;
    auto* tempElementNames = new string [elementCount];
    for(int index = 0; index < elementCount - 1; index++){
        tempElementNames[index] = elementNames[index];
    }

    int **tempMatrix = new Weight * [elementCount];
    for(int row = 0; row < elementCount; row++){
        tempMatrix[row] = new Weight [elementCount];
        for(int column = 0; column < elementCount; column++){
            if(column == elementCount-1 || row == elementCount-1){
                tempMatrix[row][column] = 0;
            }
            else{
                tempMatrix[row][column] = adjacencyMatrix[row][column];
            }
        }
    }
    delete[] elementNames;
    elementNames = tempElementNames;

    for(int row = 0; row < elementCount - 1; row++){
        delete[] adjacencyMatrix[row];
    }
    delete[] adjacencyMatrix;
    adjacencyMatrix = tempMatrix;
}


template<typename Weight>
bool DSM<Weight>::hasLink(const string &fromElement, const string &toElement) const {
    int index_from = index(fromElement);
    int index_to = index(toElement);
    if (index_from != -1 && index_to != -1) {
        if (adjacencyMatrix[index_from][index_to] != 0) {
            return true;
        }
        return false;
    }
    throw out_of_range("Index out of range");
}

template<typename Weight>
void DSM<Weight>::deleteLink(const string &fromElement, const string &toElement) {
    int index_from = index(fromElement);
    int index_to = index(toElement);
    if (index_from != -1 && index_to != -1) {
        adjacencyMatrix[index_from][index_to] = 0;
    }
}

template<typename Weight>
Weight DSM<Weight>::linkWeight(const string &fromElement, const string &toElement) const {
    int index_from = index(fromElement);
    int index_to = index(toElement);
    if (index_from != -1 && index_to != -1) {
        return adjacencyMatrix[index_from][index_to];
    }
    return -1;
}


template<typename Weight>
void DSM<Weight>::print() const {
    cout << "\t";
    for(int column = 0; column < elementCount; column++){
        cout << elementNames[column] << "\t";
    }
    cout << endl;
    for(int row = 0; row < elementCount; row++){
        cout << elementNames[row] << "\t";
        for(int column = 0; column < elementCount; column++){
            cout << adjacencyMatrix[row][column] << "\t";
        }
        cout << endl;
    }
}

template<typename Weight>
int DSM<Weight>::index(const string &elementName) const {
    int index_;
    for (int i = 0; i < elementCount; i++) {
        if (this->elementNames[i] == elementName) {
            index_ = i;
            return index_;
        }

    }
    return -1;
}


template<typename Weight>
int DSM<Weight>::countToLinks(const string &elementName) const {
    int index_ = index(elementName);
    if (index_ == -1) {
        throw out_of_range("Invalid element name");
    }
    int count = 0;
    for (int i = 0; i < elementCount; i++) {
        if (adjacencyMatrix[index_][i] != 0) {
            count++;
        }
    }
    return count;
}

template<typename Weight>
int DSM<Weight>::countFromLinks(const string &elementName) const {
    int index_ = index(elementName);
    if (index_ == -1) {
        throw out_of_range("Invalid element name");
    }
    int count = 0;
    for (int i = 0; i < elementCount; i++) {
        if (adjacencyMatrix[i][index_] != 0) {
            count++;
        }
    }
    return count;
}

template<typename Weight>
int DSM<Weight>::countAllLinks() const {
    int count = 0;
    for (int i = 0; i < elementCount; i++) {
        for (int j = 0; j < elementCount; j++) {
            if (adjacencyMatrix[i][j] != 0) {
                count++;
            }
        }
    }
    return count;
}
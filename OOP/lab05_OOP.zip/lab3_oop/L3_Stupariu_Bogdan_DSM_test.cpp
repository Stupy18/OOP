#include <iostream>
#include <cassert>
#include "L3_Stupariu_Bogdan_DSM.h"
#include "L3_Stupariu_Bogdan_DSM.cpp"
using namespace std;

void testResize(){
    string elementNames[] = {"A", "B", "C", "D", "E"};
    int elementCount = 5;

    DSM<int> dsm(elementNames, elementCount);

    // Add links between elements
    dsm.addLink("A", "B", 1);
    dsm.addLink("B", "C", 2);
    dsm.addLink("C", "D", 3);
    dsm.addLink("D", "E", 4);

    // Check link weights
    cout << "A -> B: " << dsm.linkWeight("A", "B") << endl;
    cout << "B -> C: " << dsm.linkWeight("B", "C") << endl;
    cout << "C -> D: " << dsm.linkWeight("C", "D") << endl;
    cout << "D -> E: " << dsm.linkWeight("D", "E") << endl;

    // Add link between new elements
    dsm.addLink("E", "F", 8);


    // Check link weights again
    cout << "D -> E: " << dsm.linkWeight("D", "E") << endl;
    cout << "E -> F: " << dsm.linkWeight("E", "F") << endl;
}

void testDSM() {
    DSM<int> phone(4);
    phone.setElementName(0, "Buttons");
    phone.setElementName(1, "Speaker");
    phone.setElementName(2, "Display");
    phone.setElementName(3, "Camera");
    phone.addLink("Buttons", "Speaker", 5);
    phone.addLink("Speaker", "Display", 6);
    phone.addLink("Display", "Camera", 7);
    phone.addLink("Camera", "Buttons", 8);

    assert(phone.size() == 4);
    assert(phone.getName(0) == "Buttons");
    assert(phone.getName(1) == "Speaker");
    assert(phone.getName(2) == "Display");
    assert(phone.getName(3) == "Camera");

    assert(phone.linkWeight("Buttons", "Speaker") == 5);
    assert(phone.linkWeight("Speaker", "Display") == 6);
    assert(phone.linkWeight("Display", "Camera") == 7);
    assert(phone.linkWeight("Camera", "Buttons") == 8);

    assert(phone.countFromLinks("Buttons") == 1);
    assert(phone.countToLinks("Buttons") == 1);

    assert(phone.hasLink("Buttons", "Speaker"));
    assert(!phone.hasLink("Speaker", "Buttons"));

    phone.deleteLink("Buttons", "Speaker");
    assert(!phone.hasLink("Buttons", "Speaker"));

    phone.print();

    phone.setElementName(0, "a");
    phone.setElementName(1, "b");
    phone.setElementName(2, "c");
    phone.setElementName(3,"d");

//    DSM phone2()
    DSM phone2=phone;
//    DSM phone2(phone);

    assert(phone2.countAllLinks() == 3);
    assert(phone2.size() == 4);

    phone2.print();

}

int main() {
    testResize();
    testDSM();
    cout << "All assert tests passed!" << endl;
    return 0;
}
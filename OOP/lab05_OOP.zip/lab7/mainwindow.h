#ifndef MAINWINDOW_H
#define MAINWINDOW_H


class MainWindow
{
public:
    MainWindow();
};

#endif // MAINWINDOW_H

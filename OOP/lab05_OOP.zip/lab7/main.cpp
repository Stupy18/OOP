#include <iostream>
#include <memory>
#include <cassert>
#include "Controller.h"
#include "Domain.h"
#include "Repository.h"
#include "UI.h"
#include <assert.h>
#include "test.h"
#include <QApplication>
#include "MainWindow.h"

using namespace std;
using namespace domain;
using namespace repo;
using namespace controller;
using namespace ui;



int main(int argc, char *argv[]) {
    testControllerMethods();
    uiTest();
    QApplication app(argc, argv);

    MainWindow mainWindow;
    mainWindow.show();

    return app.exec();
}

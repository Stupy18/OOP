//
// Created by stupa on 5/10/2023.
//
#include <algorithm>
#include "Controller.h" // Include the Controller header file
#include "UI.h"
#include <iostream>
#include <cctype>

using namespace std;

namespace ui {
    UI::UI() {
        // Prompt the user to choose whether to use persistent memory or not
        std::cout << "Do you want to use persistent memory? (y/n): ";
        std::string choice;
        std::cin >> choice;
        choice = stringUpperCase(choice);

        // Create the Controller instance based on the user's choice
        if (choice == "N" || choice == "NO") {
            // Create an instance of InMemoryRepository and pass it to the Controller constructor
            auto inMemoryRepository = std::make_shared<InMemoryRepository>();
            ctrl_ = std::make_shared<Controller>(inMemoryRepository);
        } else if(choice == "Y" || choice == "YES") {
            // Prompt the user to enter the CSV filename
            std::cout << "Enter the CSV filename: ";
            std::string csvFilename;
            std::cin >> csvFilename;

            // Create an instance of CSVFileRepository using the provided CSV filename
            auto csvFileRepository = std::make_shared<CSVFileRepository>(csvFilename);

            // Set the repository for the controller
            ctrl_ = std::make_shared<Controller>(csvFileRepository);
        } else
            throw invalid_argument("Invalid action");
    }

    // Function to handle the manager role
    void UI::handleManagerRole() {
        while (true) {
            // Display the menu for the manager role
            cout << "=== MANAGER MENU ===" << endl;
            cout << "1. Add a vehicle" << endl;
            cout << "2. Delete a vehicle" << endl;
            cout << "3. Update a vehicle" << endl;
            cout << "4. Search vehicles by location" << endl;
            cout << "5. Filter vehicles by age" << endl;
            cout << "6. Filter vehicles by kilometers" << endl;
            cout << "7. Sort vehicles by age" << endl;
            cout << "0. Exit" << endl;

            // Prompt the user to enter their choice
            cout << "Enter your choice: ";
            int choice;
            cin >> choice;

            // Handle the user's choice
            switch (choice) {
                case 0: // Exit the application
                    return;
                case 1: { // Add a vehicle
                    cout << "Enter the vehicle identifier: ";
                    string identifier;
                    cin >> identifier;

                    cout << "Enter the vehicle model: ";
                    string model;
                    cin >> model;

                    cout << "Enter the vehicle launch year: ";
                    int year;
                    cin >> year;

                    cout << "Enter the vehicle launch month: ";
                    int month;
                    cin >> month;

                    cout << "Enter the vehicle launch day: ";
                    int day;
                    cin >> day;

                    date launchDate = {year, month, day};

                    cout << "Enter the vehicle kilometers: ";
                    double kilometers;
                    cin >> kilometers;

                    cout << "Enter the vehicle last location: ";
                    string lastLocation;
                    cin >> lastLocation;

                    ctrl_->addVehicle(identifier, model, launchDate, kilometers, lastLocation, VehicleStatus::PARKED,"");
                    cout << "Vehicle added successfully!" << endl;
                    break;
                }
                case 2: { // Delete a vehicle
                    cout << "Enter the vehicle identifier: ";
                    string identifier;
                    cin >> identifier;

                    ctrl_->removeVehicle(identifier);
                    cout << "Vehicle deleted successfully!" << endl;
                    break;
                }
                case 3: { // Update a vehicle
                    cout << "Enter the vehicle identifier: ";
                    string identifier;
                    cin >> identifier;

                    cout << "Enter the new model: ";
                    string newModel;
                    cin >> newModel;

                    cout << "Enter the new date:";
                    date newDate;
                    cin >> newDate.year;
                    cin >> newDate.month;
                    cin >> newDate.day;

                    cout << "Enter the new kilometers: ";
                    double newKilometers;
                    cin >> newKilometers;

                    cout << "Enter the new location: ";
                    string newLocation;
                    cin >> newLocation;

                    cout << "Enter the new Status:(status:___) ";
                    string newStatus;
                    domain::VehicleStatus Status;
                    cin >> newStatus;
                    if (newStatus.find("status:") != string::npos) {
                        string statusString = newStatus.substr(7); // Extract the status string
                        if (statusString == "parked") {
                            Status = PARKED;
                        }
                        if (statusString == "reserved") {
                            Status = domain::RESERVED;
                        }
                        if (statusString == "in_use") {
                            Status = domain::IN_USE;
                        }
                        if (statusString == "maintenance") {
                            Status = domain::MAINTENANCE;
                        }
                        if (statusString == "out_of_order") {
                            Status = domain::OUT_OF_ORDER;
                        }
                    }


                    ctrl_->updateVehicle(identifier, newModel, newDate, newKilometers, newLocation, Status,"");
                    cout << "Vehicle updated successfully!" << endl;
                    break;
                }
                case 4: { // Search vehicles by location
                    cout << "Enter the location to search for: ";
                    string location;
                    cin >> location;

                    vector<Vehicle> vehicles = ctrl_->getVehiclesByLocation(stringUpperCase(location));
                    printVehicleVector(vehicles);
                    break;
                }
                case 5: { // Filter vehicles by age
                    cout << "Enter the launch year to filter by: ";
                    int year;
                    cin >> year;

                    cout << "Enter the launch month to filter by: ";
                    int month;
                    cin >> month;

                    cout << "Enter the launch day to filter by: ";
                    int day;
                    cin >> day;

                    date launchDate = {year, month, day};

                    vector<Vehicle> vehicles = ctrl_->getVehiclesByAge(launchDate);
                    printVehicleVector(vehicles);
                    break;
                }
                case 6: { // Filter vehicles by kilometers
                    cout << "Enter the maximum kilometers to filter by: ";
                    double kilometers;
                    cin >> kilometers;

                    vector<Vehicle> vehicles = ctrl_->filterVehiclesByKilometers(kilometers);
                    printVehicleVector(vehicles);
                    break;
                }
                case 7: { // Sort vehicles by age
                    vector<Vehicle> vehicles = ctrl_->getAllVehiclesSortedByAge();
                    printVehicleVector(vehicles);
                    break;
                }
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
            }
        }
    }

    // Function to handle the customer role
    void UI::handleCustomerRole() {
        string customerID;
        cout<<"Please enter your customer id:\n";
        cin>>customerID;
        ctrl_->setCurrentCustomerID(customerID);
        while (true) {
            // Display the menu for the customer role
            cout << "=== CUSTOMER MENU ===" << endl;
            cout << "1. Search vehicles by location" << endl;
            cout << "2. Filter vehicles by age" << endl;
            cout << "3. Filter vehicles by kilometers" << endl;
            cout << "4. Reserve a vehicle" << endl;
            cout << "5. Use a vehicle" << endl;
            cout << "6. See all vehicles" << endl;
            cout << "7. See all reserved vehicles\n";
            cout << "0. Exit" << endl;

            // Prompt the user to enter their choice
            cout << "Enter your choice: ";
            int choice;
            cin >> choice;

            // Handle the user's choice
            switch (choice) {
                case 0: // Exit the application
                    return;
                case 1: { // Search vehiclesByLocation by location
                    cout << "Enter the location to search for: ";
                    string location;
                    cin.ignore();
                    getline(cin, location);

                    vector<Vehicle> vehiclesByLocation = ctrl_->getVehiclesByLocation((location));
                    printVehicleVector(vehiclesByLocation);
                    break;
                }
                case 2: { // Filter vehicles by age
                    cout << "Enter the launch year to filter by: ";
                    int year;
                    cin >> year;

                    cout << "Enter the launch month to filter by: ";
                    int month;
                    cin >> month;

                    cout << "Enter the launch day to filter by: ";
                    int day;
                    cin >> day;

                    date launchDate = {year, month, day};

                    vector<Vehicle> vehicles = ctrl_->getVehiclesByAge(launchDate);
                    printVehicleVector(vehicles);
                    break;
                }
                case 3: { // Filter vehicles by kilometers
                    cout << "Enter the maximum kilometers to filter by: ";
                    double maxKilometers;
                    cin >> maxKilometers;

                    vector<Vehicle> vehicles = ctrl_->filterVehiclesByKilometers(maxKilometers);
                    printVehicleVector(vehicles);
                    break;
                }
                case 4: { // Reserve a vehicle
                    cout << "Enter the vehicle identifier: ";
                    string identifier;
                    cin >> identifier;

                    ctrl_->reserveVehicle(identifier, ctrl_->getCurrentCustomerID());
                    break;
                }
                case 5: { // Use a vehicle
                    cout << "Enter the vehicle identifier: ";
                    string identifier;
                    cin >> identifier;

                    ctrl_->useVehicle(identifier,ctrl_->getCurrentCustomerID());
                    break;
                }
                case 6: { // Use a vehicle
                    printVehicleVector(ctrl_->getAllVehiclesSortedByAge());
                    break;
                }
                case 7:{ // Get all vehicles reserved by customer
                    auto scoots = ctrl_->getReservedVehiclesForCustomer(customerID);
                    printVehicleVector(scoots);
                }
                default:
                    cout << "Invalid choice. Please try again." << endl;
                    break;
            }
        }
    }

    // Function to print the main menu
    void UI::printMenu() {

        cout<< "Welcome to the Stup-Mih-Dav Vehicle Company SRL! \n Are you a manager or a customer? Type your desired role, or 'Exit' to close the program:\n";
        string chooser;
        cin >> chooser;
        chooser = stringUpperCase(chooser);
        if (chooser == "MANAGER") {
            handleManagerRole();
        } else if (chooser == "CUSTOMER")
            handleCustomerRole();
        else if (chooser == "EXIT")
            return;
        else {
            cout << "Invalid role. Please enter 'Manager' or 'Customer' \n.";
            printMenu();
        }
    }


}

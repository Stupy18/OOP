//
// Created by stupa on 4/18/2023.
//

#ifndef LAB04_OOP_REPOSITORY_H
#define LAB04_OOP_REPOSITORY_H
using namespace std;

#include <vector>
#include "Domain.h"

namespace repository {
    class FruitRepo {
    private:
        vector<domain::Fruit> fruits_;

    public:
        void add(domain::Fruit fruit);

        void remove(domain::Fruit &fruit);

        vector<domain::Fruit> get_all() const;

        vector<domain::Fruit> search_by_name(const string &keyword) const;

        vector<domain::Fruit> get_low_quantity(int quantity) const;

        vector<domain::Fruit> sort_by_expiration_date() const;
    };

}


#endif //LAB04_OOP_REPOSITORY_H

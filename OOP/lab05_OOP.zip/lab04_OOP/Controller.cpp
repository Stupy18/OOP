//
// Created by stupa on 4/18/2023.
//

#include "Controller.h"
#include <algorithm>

namespace controller {

    void FruitController::add(string name, string origin, domain::date expiration_date, int price, int quantity) {
        domain::Fruit fruit(name, origin, expiration_date, price, quantity);
        repo_.add(fruit);
    }

//    void FruitController::remove(string name, string origin) {
//        auto it = remove_if(repo_.get_all().begin(), repo_.get_all().end(), [name, origin](const domain::Fruit &fruit) {
//            return fruit.get_name() == name && fruit.get_origin() == origin;
//        });
//
//        repo_.get_all().erase(it, repo_.get_all().end());
//    }

    void FruitController::remove(string name, string origin) {
        domain::Fruit fruit_to_remove(name, origin,{0,0,0},0,0);
        repo_.remove(fruit_to_remove);
    }


    vector<domain::Fruit> FruitController::find(string origin) {
        vector<domain::Fruit> results;
        vector<domain::Fruit> allFruits = repo_.get_all();
        for (const auto &fruit: allFruits) {
            if (fruit.get_origin() == origin) {
                results.push_back(fruit);
            }
        }
        return results;
    }

    FruitController::FruitController(repository::FruitRepo &repo) : repo_(repo) {}


}
//
// Created by stupa on 4/18/2023.
//

#ifndef LAB04_OOP_CONTROLLER_H
#define LAB04_OOP_CONTROLLER_H

#include "iostream"

#include "Repository.h"

namespace controller {

    class FruitController {
    private:
        repository::FruitRepo repo_;

    public:
        void add(string name, string origin, domain::date expiration_date, int price, int quantity);

        void remove(string name, string origin);

        vector<domain::Fruit> find(string origin);

        FruitController(repository::FruitRepo &repo);

        vector<domain::Fruit> get_all() const {
            return repo_.get_all();
        }

        vector<domain::Fruit> sort_by_expiration_date() const {
            return repo_.sort_by_expiration_date();
        }

        vector<domain::Fruit> search_by_name(const string &keyword) const {
            return repo_.search_by_name(keyword);
        }

        vector<domain::Fruit> get_low_quantity() const {
            int low_quality;
            cout << "Enter low quality value: ";
            cin >> low_quality;
            return repo_.get_low_quantity(low_quality);
        }
    };
}


#endif //LAB04_OOP_CONTROLLER_H

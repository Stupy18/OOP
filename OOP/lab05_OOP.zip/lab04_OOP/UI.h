//
// Created by stupa on 4/18/2023.
//

#ifndef LAB04_OOP_UI_H
#define LAB04_OOP_UI_H

#include "Controller.h"

namespace ui {

    class FruitUI {
    private:
        controller::FruitController ctrl_;

    public:

        FruitUI(controller::FruitController &controller);

        void run();

        void print_menu();

        void print_fruits(vector <domain::Fruit> fruits);

    };
}

#endif //LAB04_OOP_UI_H

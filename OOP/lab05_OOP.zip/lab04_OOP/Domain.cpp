//
// Created by stupa on 4/18/2023.
//
using namespace std;

#include "Domain.h"
#include <algorithm>

namespace domain {

    Fruit::Fruit(string name, string origin, date expiration_date, int price = 0, int amount = 0) {
        this->name_ = name;
        this->origin_ = origin;
        this->expiration_date_ = expiration_date;
        this->price_ = price;
        this->amount_ = amount;

    }

    string Fruit::get_name() const {
        return name_;
    }

    string Fruit::get_origin() const {
        return origin_;
    }

    date Fruit::get_expiration_date() const {
        return expiration_date_;
    }

    int Fruit::get_price() const {
        return price_;
    }

    int Fruit::get_amount() const {
        return amount_;
    }

    void Fruit::set_amount(int amount) {
        amount_ = amount;
    }

    void Fruit::set_price(int price) {
        price_ = price;
    }

}
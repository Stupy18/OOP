//
// Created by stupa on 4/18/2023.
//

#include "Repository.h"
#include <algorithm>

bool sort_by_name(const domain::Fruit &a, const domain::Fruit &b) {
    return a.get_name() < b.get_name();
}

// hier ist der Komparison fur sort_by_expiration_date method, wenn a.jahr=b.jahr dann probieren wir a.monat mit b.monat und so fur a.tag und b.tag
bool sort_by_expiration_date_(const domain::Fruit &a, const domain::Fruit &b) {
    if (a.get_expiration_date().year != b.get_expiration_date().year) {
        return a.get_expiration_date().year < b.get_expiration_date().year;
    } else if (a.get_expiration_date().month != b.get_expiration_date().month) {
        return a.get_expiration_date().month < b.get_expiration_date().month;
    }
    return a.get_expiration_date().day < b.get_expiration_date().day;
}

namespace repository {

    void FruitRepo::add(domain::Fruit fruit) {
        for (auto &existing_fruit: fruits_) {
            if (existing_fruit.get_name() == fruit.get_name() && existing_fruit.get_origin() == fruit.get_origin()) {
                existing_fruit.set_amount(fruit.get_amount() + existing_fruit.get_amount());
                //fruit.get_amount()+existing_fruit.get_amount ist der Total also das wird als set_amount benutzt
                return;
            }
        }
        fruits_.push_back(fruit);
    }

    void FruitRepo::remove(domain::Fruit &fruit) {
        for (auto it = fruits_.begin(); it != fruits_.end(); ++it) {
            if (it->get_name() == fruit.get_name()) {
                fruits_.erase(it);
                break;
            }
        }
    }

    vector <domain::Fruit> FruitRepo::get_all() const {
        return fruits_;
    }

    vector <domain::Fruit> FruitRepo::search_by_name(const string &keyword) const {
        vector <domain::Fruit> result;
            if (keyword.empty()) {
                    result=this->get_all();//wenn keyword is "", also nichts, wird result der ganze Fruit Vector sein
            } else
                for (const auto &fruit: fruits_) {
                    if (fruit.get_name().find(keyword) != string::npos) {
                        result.push_back(fruit); //string::npos heist no position, also soll der keyword zwischen 0 und lange des Wortes sein damit es in result getan werden soll
                    }
                }
        sort(result.begin(), result.end(), sort_by_name);
        return result;
    }

    vector <domain::Fruit> FruitRepo::get_low_quantity(int quantity) const {
        vector <domain::Fruit> result;
        for (const auto &fruit: fruits_) {
            if (fruit.get_amount() <= quantity) {
                result.push_back(fruit); //wenn quantity von fruit kleiner gleich als der int als parameter gegeben, dass stellen wir es in result
            }
        }
        return result;
    }

    vector <domain::Fruit> FruitRepo::sort_by_expiration_date() const {
        vector <domain::Fruit> result = fruits_;
        sort(result.begin(), result.end(), sort_by_expiration_date_);
        return result;
    }


}
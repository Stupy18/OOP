//
// Created by stupa on 4/18/2023.
//

#ifndef LAB04_OOP_DOMAIN_H
#define LAB04_OOP_DOMAIN_H

#include <string>

namespace domain {

    struct date {
        int year = 0;
        int month = 0;
        int day = 0;
    };

    class Fruit {
    private:
        string name_;
        string origin_;
        date expiration_date_={0,0,0};
        int price_=0;
        int amount_=0;

    public:
        Fruit(string name, string origin, date expiration_date, int price, int amount);

        string get_name() const;

        string get_origin() const;

        date get_expiration_date() const;

        int get_price() const;

        int get_amount() const;

        void set_amount(int amount);

        void set_price(int price);
    };

}


#endif //LAB04_OOP_DOMAIN_H

#include <iostream>
#include "Repository.h"
#include "Controller.h"
#include "Domain.h"
#include "UI.h"
#include <cassert>
#include <algorithm>
using namespace std;
using namespace controller;
using namespace domain;
using namespace repository;
using namespace ui;

void controller_tests() {
    FruitRepo repo;
    FruitController controller(repo);
    controller.add("apple", "USA", {2023, 1, 1}, 2, 100);
    controller.add("banana", "Brazil", {2023, 1, 1}, 3, 50);
    controller.add("orange", "Spain", {2023, 1, 1}, 1, 200);
    controller.add("kiwi", "Italy", {2023, 1, 1}, 4, 75);
    controller.add("pear", "USA", {2023, 1, 1}, 2, 150);
    controller.add("grape", "France", {2023, 1, 1}, 5, 25);
    controller.add("watermelon", "USA", {2023, 1, 1}, 8, 10);
    controller.add("pineapple", "Costa Rica", {2023, 1, 1}, 6, 30);
    controller.add("mango", "Mexico", {2023, 1, 1}, 4, 40);
    controller.add("peach", "USA", {2023, 1, 1}, 3, 75);

    // test the get_all() function
    auto all_fruits = controller.get_all();
    assert(all_fruits.size() == 10);

    // test the remove() function
    controller.remove("apple", "USA");
    all_fruits = controller.get_all();
    assert(all_fruits.size() == 9);

    //neues controller fur andere Teste
    FruitController ctrl(repo);
    ctrl.add("apple", "USA", {2023, 6, 1}, 2, 10);
    ctrl.add("banana", "Brazil", {2023, 6, 15}, 1, 5);
    ctrl.add("orange", "Spain", {2023, 5, 31}, 3, 8);
    ctrl.add("mango", "India", {2023, 7, 1}, 4, 3);

// Test finding fruits by origin
    vector<Fruit> fruits = ctrl.find("USA");
    assert(fruits.size() == 1 && fruits[0].get_name() == "apple");

    fruits = ctrl.find("Brazil");
    assert(fruits.size() == 1 && fruits[0].get_name() == "banana");

    fruits = ctrl.find("Spain");
    assert(fruits.size() == 1 && fruits[0].get_name() == "orange");

    fruits = ctrl.find("India");
    assert(fruits.size() == 1 && fruits[0].get_name() == "mango");

    fruits = ctrl.find("Italy");
    assert(fruits.empty());

}

void repository_tests(){
    FruitRepo repo;
    repo.add(domain::Fruit("apple", "USA", {2023, 5, 1}, 5, 10));
    repo.add(domain::Fruit("orange", "Mexico", {2023, 5, 3}, 6, 5));
    repo.add(domain::Fruit("banana", "Brazil", {2023, 5, 2}, 4, 20));
    repo.add(domain::Fruit("kiwi", "New Zealand", {2023, 5, 4}, 8, 15));

    //Tests for search_by_name
    vector<Fruit> result = repo.search_by_name("apple");
    assert(result.size() == 1);
    assert(result[0].get_name() == "apple");

    vector<Fruit> result2 = repo.search_by_name("an");
    assert(result2.size() == 2);
    assert(result2[0].get_name() == "banana");
    assert(result2[1].get_name() == "orange");

    vector<Fruit> result3 = repo.search_by_name("watermelon");
    assert(result3.empty());

    //Tests for get_low_quantity
    vector<Fruit> result4 = repo.get_low_quantity(10);
    assert(result4.size() == 2);
    assert(result4[0].get_name() == "apple");
    assert(result4[1].get_name() == "orange");

    vector<Fruit> result5 = repo.get_low_quantity(4);
    assert(result5.empty());

    //Test for sort_by_expiration_date
    vector<Fruit> result6 = repo.sort_by_expiration_date();
    assert(result6.size() == 4);
    assert(result6[0].get_name() == "apple");
    assert(result6[1].get_name() == "banana");
    assert(result6[2].get_name() == "orange");
    assert(result6[3].get_name() == "kiwi");

}
int main() {
    controller_tests();
    repository_tests();
    FruitRepo repo;
    FruitController controller(repo);
    controller.add("apple", "USA", {2023, 1, 1}, 2, 100);
    controller.add("banana", "Brazil", {2023, 1, 5}, 3, 50);
    controller.add("orange", "Spain", {2023, 1, 7}, 1, 200);
    controller.add("kiwi", "Italy", {2023, 1, 9}, 4, 75);
    controller.add("pear", "USA", {2023, 1, 23}, 2, 150);
    controller.add("grape", "France", {2023, 1, 14}, 5, 25);
    controller.add("watermelon", "USA", {2023, 1, 12}, 8, 10);
    controller.add("pineapple", "Costa Rica", {2023, 12, 1}, 6, 30);
    controller.add("mango", "Mexico", {2023, 1, 16}, 4, 40);
    controller.add("peach", "USA", {2023, 1, 1}, 3, 75);
    FruitUI UI(controller);
    UI.run();
    return 0;
}

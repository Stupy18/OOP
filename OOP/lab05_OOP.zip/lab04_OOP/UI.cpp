#include "Repository.h"
#include "Controller.h"
#include "Domain.h"
#include "UI.h"
#include <iostream>

using namespace std;
#include <algorithm>

namespace ui {

    FruitUI::FruitUI(controller::FruitController &controller) : ctrl_(controller) {}

    void FruitUI::run() {
        int option;
        while (true) {
            print_menu();
            cout << "Enter option: ";
            cin >> option;
            cin.ignore();
            if (option == 0) {
                break;
            }
            switch (option) {
                case 1: {
                    string name, origin;
                    domain::date expiration_date;
                    int price, amount;
                    cout << "Enter fruit name: ";
                    getline(cin, name);
                    cout << "Enter fruit origin: ";
                    getline(cin, origin);
                    cout << "Enter expiration date (yyyy mm dd): ";
                    cin >> expiration_date.year >> expiration_date.month >> expiration_date.day;
                    cout << "Enter price: ";
                    cin >> price;
                    cout << "Enter amount: ";
                    cin >> amount;
                    ctrl_.add(name, origin, expiration_date, price, amount);
                    break;
                }
                case 2: {
                    string name, origin;
                    cout << "Enter fruit name: ";
                    getline(cin, name);
                    cout << "Enter fruit origin: ";
                    getline(cin, origin);
                    ctrl_.remove(name, origin);
                    break;
                }
                case 3: {
                    string origin;
                    cout << "Enter fruit origin: ";
                    getline(cin, origin);
                    vector<domain::Fruit> fruits = ctrl_.find(origin);
                    print_fruits(fruits);
                    break;
                }
                case 4: {
                    vector<domain::Fruit> fruits = ctrl_.get_all();
                    print_fruits(fruits);
                    break;
                }
                case 5: {
                    string keyword;
                    cout << "Enter a keyword: ";
                    cin.ignore();
                    getline(cin, keyword);
                    vector<domain::Fruit> fruits = ctrl_.search_by_name(keyword);
                    if (fruits.empty()) {
                        cout << "No fruits found." << endl;
                    } else {
                        print_fruits(fruits);
                    }
                    break;
                }
                case 6: {
                    vector<domain::Fruit> fruits = ctrl_.get_low_quantity();
                    if (fruits.empty()) {
                        cout << "No fruits found." << endl;
                    } else {
                        print_fruits(fruits);
                    }
                    break;
                }
                case 7: {
                    vector<domain::Fruit> fruits = ctrl_.sort_by_expiration_date();
                    if (fruits.empty()) {
                        cout << "No fruits found." << endl;
                    } else {
                        print_fruits(fruits);
                    }
                    break;
                }
                default:
                    cout << "Invalid option!" << endl;
            }
        }
    }


    void FruitUI::print_menu() {
        cout << "Available options:\n"
             << "1. Add a fruit.\n"
             << "2. Remove a fruit.\n"
             << "3. Find fruits by origin.\n"
             << "4. Get all fruits.\n"
             << "5. Get fruits by name.\n"
             << "6. Get fruits by low quantity.\n"
             << "7. Sort by expiration date.\n"
             << "0. Exit.\n";
    }

    void FruitUI::print_fruits(vector <domain::Fruit> fruits) {
        if (fruits.empty()) {
            cout << "No fruits found." << endl;
            return;
        }
        cout << "Fruits:\n";
        for (auto fruit: fruits) {
            cout << "Name: " << fruit.get_name() << endl;
            cout << "Origin: " << fruit.get_origin() << endl;
            cout << "Expiration date: " << fruit.get_expiration_date().year << "/"
                 << fruit.get_expiration_date().month << "/"
                 << fruit.get_expiration_date().day << endl;
            cout << "Price: " << fruit.get_price() << endl;
            cout << "Amount: " << fruit.get_amount() << endl;
            cout << endl;
        }
    }

}